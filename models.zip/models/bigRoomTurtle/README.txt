PUT AT /home/USER/building_editor_models/bigRoomTurtle
