PUT AT /home/USER/model_editor_models/cylinders
